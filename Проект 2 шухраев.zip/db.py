from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

DSN = "mysql+pymysql://root:root@localhost:3306/payments_app?charset=utf8mb4"
engine = create_engine(DSN, echo=False)
Session = sessionmaker(bind=engine)
