from PyQt6 import QtWidgets, QtCore
from PyQt6.QtCore import QDate, QAbstractTableModel, Qt, pyqtSignal
from db import Session
from models import User, Payment
import bcrypt, datetime, os, re
from docx import Document
from docx.shared import Pt


class LoginForm(QtWidgets.QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Идентификация пользователя")
        self.resize(300, 120)
        self.current_user = None

        self.cmb_login = QtWidgets.QComboBox()
        self.txt_password = QtWidgets.QLineEdit()
        self.txt_password.setEchoMode(QtWidgets.QLineEdit.EchoMode.Password)
        btn_ok = QtWidgets.QPushButton("Войти")
        btn_cancel = QtWidgets.QPushButton("Отмена")

        form = QtWidgets.QFormLayout(self)
        form.addRow("Логин:", self.cmb_login)
        form.addRow("Пароль:", self.txt_password)
        hl = QtWidgets.QHBoxLayout(); hl.addWidget(btn_ok); hl.addWidget(btn_cancel)
        form.addRow(hl)

        for u in Session().query(User).order_by(User.username):
            self.cmb_login.addItem(u.username, u.id)

        btn_ok.clicked.connect(self.do_login)
        btn_cancel.clicked.connect(self.reject)

    def do_login(self):
        uid = self.cmb_login.currentData()
        pwd = self.txt_password.text().strip()
        user = Session().get(User, uid)
        if not user or not bcrypt.checkpw(pwd.encode('utf-8'), user.password_hash.encode('utf-8')):
            QtWidgets.QMessageBox.warning(self, "Ошибка", "Неверный логин или пароль.")
            self.txt_password.clear()
            return
        self.current_user = user
        self.accept()


class PaymentsTableModel(QAbstractTableModel):
    def __init__(self, payments, headers, parent=None):
        super().__init__(parent)
        self._data = payments
        self._headers = headers

    def rowCount(self, parent=QtCore.QModelIndex()):
        return len(self._data)

    def columnCount(self, parent=QtCore.QModelIndex()):
        return len(self._headers)

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid() or role != Qt.ItemDataRole.DisplayRole:
            return None
        p = self._data[index.row()]
        vals = [
            p.id, p.category, p.description,
            p.quantity,
            f"{float(p.price):.2f}",
            f"{float(p.total):.2f}",
            p.payment_date.strftime("%Y-%m-%d")
        ]
        return str(vals[index.column()])

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):
        if role == Qt.ItemDataRole.DisplayRole:
            if orientation == Qt.Orientation.Horizontal:
                return self._headers[section]
            return section + 1
        return None


class ViewForm(QtWidgets.QWidget):
    def __init__(self, user):
        super().__init__()
        self.user = user
        self.session = Session()

        # Фильтры
        self.date_from = QtWidgets.QDateEdit(calendarPopup=True)
        self.date_to   = QtWidgets.QDateEdit(calendarPopup=True)
        today = QDate.currentDate()
        self.date_from.setDate(today.addMonths(-1))
        self.date_to.setDate(today)
        self.cmb_category = QtWidgets.QComboBox()
        self.cmb_category.addItem("Все категории", None)
        self.btn_filter = QtWidgets.QPushButton("Фильтровать")
        self.table = QtWidgets.QTableView()

        hl = QtWidgets.QHBoxLayout()
        hl.addWidget(QtWidgets.QLabel("С:"));    hl.addWidget(self.date_from)
        hl.addWidget(QtWidgets.QLabel("По:"));   hl.addWidget(self.date_to)
        hl.addWidget(QtWidgets.QLabel("Категория:")); hl.addWidget(self.cmb_category)
        hl.addWidget(self.btn_filter)
        layout = QtWidgets.QVBoxLayout(self)
        layout.addLayout(hl)
        layout.addWidget(self.table)

        self.btn_filter.clicked.connect(self.load_data)
        self.load_categories()
        self.load_data()

    def load_categories(self):
        self.cmb_category.clear()
        self.cmb_category.addItem("Все категории", None)
        cats = (
            self.session.query(Payment.category)
            .filter(Payment.user_id == self.user.id)
            .distinct().all()
        )
        for (c,) in cats:
            self.cmb_category.addItem(c, c)

    def load_data(self):
        q = (
            self.session.query(Payment)
            .filter(Payment.user_id == self.user.id)
            .filter(
                Payment.payment_date >= self.date_from.date().toPyDate(),
                Payment.payment_date <= self.date_to.date().toPyDate()
            )
        )
        cat = self.cmb_category.currentData()
        if cat:
            q = q.filter(Payment.category == cat)
        payments = q.order_by(Payment.category, Payment.payment_date).all()

        headers = ["ID","Категория","Описание","Кол-во","Цена","Итого","Дата"]
        model = PaymentsTableModel(payments, headers, self)
        self.table.setModel(model)
        self.table.resizeColumnsToContents()


class AddForm(QtWidgets.QWidget):
    payment_added = pyqtSignal()
    def __init__(self, user):
        super().__init__()
        self.user = user
        self.session = Session()

        self.cmb_category = QtWidgets.QComboBox()
        self.cmb_category.setEditable(True)
        self.txt_desc = QtWidgets.QLineEdit()
        self.spn_qty = QtWidgets.QSpinBox()
        self.spn_qty.setMinimum(1)
        self.txt_price = QtWidgets.QLineEdit()
        self.btn_add = QtWidgets.QPushButton("Добавить")

        form = QtWidgets.QFormLayout(self)
        form.addRow("Категория:", self.cmb_category)
        form.addRow("Назначение:", self.txt_desc)
        form.addRow("Количество:", self.spn_qty)
        form.addRow("Цена:", self.txt_price)
        form.addRow(self.btn_add)

        self.load_categories()
        self.btn_add.clicked.connect(self.on_add)

    def load_categories(self):
        self.cmb_category.clear()
        cats = (
            self.session.query(Payment.category)
            .filter(Payment.user_id == self.user.id)
            .distinct().all()
        )
        for (c,) in cats:
            self.cmb_category.addItem(c)

    def on_add(self):
        desc = self.txt_desc.text().strip()
        if len(desc) < 3 or not re.match(r'^[А-ЯЁа-яё ]+$', desc):
            QtWidgets.QMessageBox.warning(self, "Ошибка", "Назначение: минимум 3 русских буквы.")
            return
        try:
            price = float(self.txt_price.text().strip())
            assert price >= 0
        except:
            QtWidgets.QMessageBox.warning(self, "Ошибка", "Цена должна быть неотрицательным числом.")
            return
        qty = self.spn_qty.value()
        cat = self.cmb_category.currentText().strip()
        if not cat:
            QtWidgets.QMessageBox.warning(self, "Ошибка", "Укажите категорию.")
            return
        # Создание платежа
        p = Payment(
            user_id=self.user.id,
            category=cat,
            description=desc,
            quantity=qty,
            price=price,
            total=qty * price,
            payment_date=datetime.datetime.now()
        )
        self.session.add(p)
        self.session.commit()
        self.payment_added.emit()
        QtWidgets.QMessageBox.information(self, "Успех", "Платеж добавлен.")
        self.txt_desc.clear()
        self.txt_price.clear()
        self.spn_qty.setValue(1)
        self.load_categories()


class DeleteForm(QtWidgets.QWidget):
    payment_deleted = pyqtSignal()
    def __init__(self, user):
        super().__init__()
        self.user = user
        self.session = Session()

        self.table = QtWidgets.QTableView()
        btn = QtWidgets.QPushButton("Удалить выделенное")
        lay = QtWidgets.QVBoxLayout(self)
        lay.addWidget(self.table)
        lay.addWidget(btn)

        btn.clicked.connect(self.on_delete)
        self.load_data()

    def load_data(self):
        pays = (
            self.session.query(Payment)
            .filter_by(user_id=self.user.id)
            .order_by(Payment.category, Payment.payment_date)
            .all()
        )
        hdr = ["ID","Категория","Описание","Кол-во","Цена","Итого","Дата"]
        model = PaymentsTableModel(pays, hdr, self)
        self.table.setModel(model)
        self.table.resizeColumnsToContents()

    def on_delete(self):
        idx = self.table.currentIndex()
        if not idx.isValid():
            return
        pay = idx.model()._data[idx.row()]
        reply = QtWidgets.QMessageBox.question(
            self, "Удаление",
            f"Удалить '{pay.description}' на сумму {pay.total:.2f} RUR?",
            QtWidgets.QMessageBox.StandardButton.Yes | QtWidgets.QMessageBox.StandardButton.No
        )
        if reply != QtWidgets.QMessageBox.StandardButton.Yes:
            return
        QtWidgets.QApplication.beep()
        self.session.delete(pay)
        self.session.commit()
        self.payment_deleted.emit()
        self.load_data()


class ReportForm(QtWidgets.QWidget):
    def __init__(self, user):
        super().__init__()
        self.user = user
        self.session = Session()

        self.date_from = QtWidgets.QDateEdit(calendarPopup=True)
        self.date_to = QtWidgets.QDateEdit(calendarPopup=True)
        t = QDate.currentDate()
        self.date_from.setDate(t.addMonths(-1))
        self.date_to.setDate(t)
        self.cmb_category = QtWidgets.QComboBox()
        self.cmb_category.addItem("Все категории", None)
        self.btn = QtWidgets.QPushButton("Сформировать отчёт")

        hl = QtWidgets.QHBoxLayout()
        hl.addWidget(QtWidgets.QLabel("С:"));    hl.addWidget(self.date_from)
        hl.addWidget(QtWidgets.QLabel("По:"));   hl.addWidget(self.date_to)
        hl.addWidget(QtWidgets.QLabel("Категория:")); hl.addWidget(self.cmb_category)
        hl.addWidget(self.btn)
        lay = QtWidgets.QVBoxLayout(self)
        lay.addLayout(hl)

        self.btn.clicked.connect(self.generate)
        self.load_categories()

    def load_categories(self):
        cats = (
            self.session.query(Payment.category)
            .filter(Payment.user_id == self.user.id)
            .distinct().all()
        )
        for (c,) in cats:
            self.cmb_category.addItem(c, c)

    def generate(self):
        fn, _ = QtWidgets.QFileDialog.getSaveFileName(
            self, "Сохранить отчёт", f"report_{self.user.username}.docx",
            "Word (*.docx);;PDF (*.pdf)"
        )
        if not fn:
            return
        is_pdf = fn.lower().endswith('.pdf')
        tmp = fn if not is_pdf else fn[:-4] + '.docx'

        # Создание документа
        doc = Document()
        sect = doc.sections[0]
        hdr = sect.header.paragraphs[0]
        hdr.text = f"{self.user.full_name}    Страница " + "PAGE"
        sect.footer.paragraphs[0].text = f"Отчет по платежам"

        doc.add_heading(f"Отчёт {self.user.full_name}", level=1)
        doc.add_paragraph(
            f"Период: {self.date_from.date().toString('yyyy-MM-dd')} — {self.date_to.date().toString('yyyy-MM-dd')}"
        )
        cat = self.cmb_category.currentData()
        if cat:
            doc.add_paragraph(f"Категория: {cat}")

        pays = (
            self.session.query(Payment)
            .filter(Payment.user_id == self.user.id)
            .filter(
                Payment.payment_date >= self.date_from.date().toPyDate(),
                Payment.payment_date <= self.date_to.date().toPyDate()
            )
        )
        if cat:
            pays = pays.filter(Payment.category == cat)
        pays = pays.order_by(Payment.category, Payment.payment_date).all()

        total_sum = 0
        from itertools import groupby
        for category, group in groupby(pays, key=lambda p: p.category):
            doc.add_heading(category, level=2)
            table = doc.add_table(rows=1, cols=6)
            hdr_cells = table.rows[0].cells
            cols = ["Дата","Назначение","Кол-во","Цена","Итого"]
            for i, title in enumerate(cols):
                hdr_cells[i].text = title
            for pmt in sorted(group, key=lambda x: x.payment_date):
                row_cells = table.add_row().cells
                row_cells[0].text = pmt.payment_date.strftime('%Y-%m-%d')
                row_cells[1].text = pmt.description
                row_cells[2].text = str(pmt.quantity)
                row_cells[3].text = f"{float(pmt.price):.2f}"
                row_cells[4].text = f"{float(pmt.total):.2f}"
                total_sum += float(pmt.total)

        doc.add_paragraph(f"Общая сумма всех платежей: {total_sum:.2f}")
        doc.save(tmp)
        if is_pdf:
            try:
                from docx2pdf import convert
                convert(tmp, fn)
                os.remove(tmp)
            except ImportError:
                QtWidgets.QMessageBox.warning(self, "PDF", "Установите docx2pdf.")
                return
        QtWidgets.QMessageBox.information(self, "Готово", f"Сохранено: {fn}")