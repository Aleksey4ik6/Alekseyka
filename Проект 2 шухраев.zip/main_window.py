# File: main_window.py

from PyQt6 import QtWidgets, QtGui, QtCore
from PyQt6.QtCore import QDate
from forms import ViewForm, AddForm, DeleteForm, ReportForm

class MainWindow(QtWidgets.QMainWindow):
    def __init__(self, user):
        super().__init__()
        self.user = user
        self.setWindowTitle(f"Учёт платежей — {user.full_name}")
        self.resize(1000, 700)

        # --- Меню ---
        menubar = self.menuBar()
        file_menu = menubar.addMenu("Файл")
        file_menu.addAction("Выход", self.close)
        help_menu = menubar.addMenu("Справка")
        help_menu.addAction("О программе", self.show_about)

        # --- Панель инструментов слева ---
        toolbar = QtWidgets.QToolBar("MainToolbar")
        toolbar.setIconSize(QtCore.QSize(24, 24))
        self.addToolBar(QtCore.Qt.ToolBarArea.LeftToolBarArea, toolbar)

        view_act = QtGui.QAction(QtGui.QIcon.fromTheme("view-list"), "Просмотр", self)
        add_act  = QtGui.QAction(QtGui.QIcon.fromTheme("list-add"), "Добавить", self)
        del_act  = QtGui.QAction(QtGui.QIcon.fromTheme("edit-delete"), "Удалить", self)
        rpt_act  = QtGui.QAction(QtGui.QIcon.fromTheme("document-properties"), "Отчёт", self)

        toolbar.addAction(view_act)
        toolbar.addAction(add_act)
        toolbar.addAction(del_act)
        toolbar.addAction(rpt_act)

        # --- Боковая навигация ---
        sidebar = QtWidgets.QListWidget()
        sidebar.addItems(["Просмотр", "Добавить", "Удалить", "Отчёт"])
        sidebar.setFixedWidth(160)

        # --- Стек страниц (форм) ---
        self.stack = QtWidgets.QStackedWidget()
        self.stack.addWidget(ViewForm(user))
        self.stack.addWidget(AddForm(user))
        self.stack.addWidget(DeleteForm(user))
        self.stack.addWidget(ReportForm(user))

        # Синхронизация действий тулбара и сайдбара
        view_act.triggered.connect(lambda: sidebar.setCurrentRow(0))
        add_act.triggered.connect(lambda: sidebar.setCurrentRow(1))
        del_act.triggered.connect(lambda: sidebar.setCurrentRow(2))
        rpt_act.triggered.connect(lambda: sidebar.setCurrentRow(3))
        sidebar.currentRowChanged.connect(self.stack.setCurrentIndex)

        # --- Основная разметка: горизонтальный Splitter ---
        splitter = QtWidgets.QSplitter()
        splitter.addWidget(sidebar)
        splitter.addWidget(self.stack)
        splitter.setStretchFactor(1, 1)

        container = QtWidgets.QWidget()
        hl = QtWidgets.QHBoxLayout(container)
        hl.addWidget(splitter)
        self.setCentralWidget(container)

        # --- Статус‑бар ---
        self.statusBar().showMessage("Готово")

        # Инициализируем первую страницу
        sidebar.setCurrentRow(0)

    def show_about(self):
        QtWidgets.QMessageBox.about(
            self, "О программе",
            f"Учёт платежей v1.0\nПользователь: {self.user.full_name}"
        )
