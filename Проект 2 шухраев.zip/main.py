# File: main.py

import sys
from PyQt6 import QtWidgets
from forms import LoginForm
from main_window import MainWindow

def main():
    app = QtWidgets.QApplication(sys.argv)

    # Диалог авторизации
    login = LoginForm()
    if login.exec() != QtWidgets.QDialog.DialogCode.Accepted:
        sys.exit(0)
    user = login.current_user

    # Основное окно
    win = MainWindow(user)
    win.show()

    sys.exit(app.exec())

if __name__ == "__main__":
    main()
