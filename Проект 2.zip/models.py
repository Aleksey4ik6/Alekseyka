from sqlalchemy import Column, Integer, String, DECIMAL, DateTime, ForeignKey
from sqlalchemy.orm import declarative_base, relationship
import bcrypt

Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    id            = Column(Integer, primary_key=True)
    username      = Column(String(50), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    full_name     = Column(String(100), nullable=False)
    payments      = relationship("Payment", back_populates="user", cascade="all, delete")

    def check_password(self, plain: str) -> bool:
        return bcrypt.checkpw(plain.encode("utf-8"), self.password_hash.encode("utf-8"))

class Payment(Base):
    __tablename__ = "payments"
    id           = Column(Integer, primary_key=True)
    user_id      = Column(Integer, ForeignKey("users.id"), nullable=False)
    category     = Column(String(50), nullable=False)
    description  = Column(String(255), nullable=False)
    quantity     = Column(Integer, nullable=False)
    price        = Column(DECIMAL(10,2), nullable=False)
    total        = Column(DECIMAL(12,2), nullable=False)
    payment_date = Column(DateTime, nullable=False)
    user         = relationship("User", back_populates="payments")
