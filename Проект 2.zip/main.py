import sys
from PyQt6 import QtWidgets
from forms import LoginForm, ViewForm, AddForm, DeleteForm, ReportForm

def main():
    app = QtWidgets.QApplication(sys.argv)

    login = LoginForm()
    if login.exec() != QtWidgets.QDialog.DialogCode.Accepted:
        sys.exit(0)
    user = login.current_user

    tabs = QtWidgets.QTabWidget()
    tabs.setWindowTitle(f"Учёт платежей — {user.full_name}")
    tabs.resize(800, 600)

    view_tab   = ViewForm(user)
    add_tab    = AddForm(user)
    delete_tab = DeleteForm(user)
    report_tab = ReportForm(user)

    # Сигналы «Добавлено» и «Удалено» теперь обновляют ViewForm
    add_tab.payment_added.connect(view_tab.load_data)
    delete_tab.payment_deleted.connect(view_tab.load_data)

    tabs.addTab(view_tab,   "Просмотр")
    tabs.addTab(add_tab,    "Добавить")
    tabs.addTab(delete_tab, "Удалить")
    tabs.addTab(report_tab, "Отчёт")

    tabs.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()