# import_data.py

import os
import pandas as pd
from sqlalchemy import (create_engine, MetaData, Table, Column,
                        Integer, String, DECIMAL, DateTime, ForeignKey, text)
from sqlalchemy.orm import sessionmaker
import bcrypt
import datetime

# =========== MYSQL CONNECTION SETTINGS ============
MYSQL_USER     = 'root'
MYSQL_PASSWORD = 'root'  # <- замените на ваш пароль
MYSQL_HOST     = 'localhost'
MYSQL_PORT     = 3306
MYSQL_DB       = 'payments_app'

# ID пользователя, к которому приоритетно привязываем платежи
TARGET_USER_ID = 10

# Строка подключения к MySQL
DSN = (
    f"mysql+pymysql://{MYSQL_USER}:{MYSQL_PASSWORD}@{MYSQL_HOST}:{MYSQL_PORT}/{MYSQL_DB}"
    "?charset=utf8mb4"
)
engine = create_engine(DSN, echo=False)
Session = sessionmaker(bind=engine)
session = Session()

# ============ Files paths ============
BASE_DIR      = os.path.dirname(os.path.abspath(__file__))
USERS_XLSX    = os.path.join(BASE_DIR, 'Список пользователей.xlsx')
PAYMENTS_XLSX = os.path.join(BASE_DIR, 'Список платежей.xlsx')

# ============ Read Excel ============
print("Читаем Excel-файлы...")
users_df    = pd.read_excel(USERS_XLSX,    sheet_name=0)
payments_df = pd.read_excel(PAYMENTS_XLSX, sheet_name=0)

# ============ Define tables ============
metadata = MetaData()

users_table = Table('users', metadata,
    Column('id',            Integer, primary_key=True),
    Column('username',      String(50),  nullable=False, unique=True),
    Column('password_hash', String(255), nullable=False),
    Column('full_name',     String(100), nullable=False),
    Column('pin_code',      String(20),  nullable=True),  # добавляем PIN
)

payments_table = Table('payments', metadata,
    Column('id',           Integer, primary_key=True),
    Column('user_id',      Integer, ForeignKey('users.id', ondelete='CASCADE'), nullable=False),
    Column('category',     String(50),  nullable=False),
    Column('description',  String(255), nullable=False),
    Column('quantity',     Integer,    nullable=False),
    Column('price',        DECIMAL(10,2), nullable=False),
    Column('total',        DECIMAL(12,2), nullable=False),
    Column('payment_date', DateTime,   nullable=False),
)

# Создаём/обновляем схемы (добавит колонку pin_code, если её нет)
metadata.create_all(engine)

# ============ Password hashing ============
def hash_password(plain: str) -> str:
    salt = bcrypt.gensalt()
    return bcrypt.hashpw(plain.encode('utf-8'), salt).decode('utf-8')

# ============ Truncate tables ============
print("Очищаем таблицы users и payments...")
with engine.begin() as conn:
    conn.execute(text("SET FOREIGN_KEY_CHECKS=0"))
    conn.execute(text("TRUNCATE TABLE payments"))
    conn.execute(text("TRUNCATE TABLE users"))
    conn.execute(text("SET FOREIGN_KEY_CHECKS=1"))

# ============ Insert users ============
print("Вставляем пользователей...")
users_to_insert = []
for _, row in users_df.iterrows():
    users_to_insert.append({
        'id':            int(row['ID']),
        'username':      str(row['LOGIN']),
        'full_name':     str(row['FIO']),
        'password_hash': hash_password(str(row['PASSWORD'])),
        'pin_code':      str(row['PIN-CODE']),
    })

with engine.begin() as conn:
    conn.execute(users_table.insert(), users_to_insert)
print(f"  → Добавлено {len(users_to_insert)} пользователей.")

# ============ Insert payments ============
print(f"Вставляем платежи для user_id={TARGET_USER_ID}...")
payments_to_insert = []
for _, row in payments_df.iterrows():
    dt = row['Дата']
    if not isinstance(dt, datetime.datetime):
        dt = pd.to_datetime(dt)

    qty   = int(row['Количество'])
    price = float(row['Цена'])

    payments_to_insert.append({
        'user_id':      TARGET_USER_ID,
        'category':     str(row['Категория']),
        'description':  str(row['Наименование платежа']),
        'quantity':     qty,
        'price':        price,
        'total':        qty * price,
        'payment_date': dt,
    })

with engine.begin() as conn:
    conn.execute(payments_table.insert(), payments_to_insert)
print(f"  → Добавлено {len(payments_to_insert)} платежей.")

print("✅ Импорт данных завершён успешно!")
